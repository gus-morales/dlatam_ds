-- cleans and recreates db
DROP DATABASE IF EXISTS morales_gustavo;
CREATE DATABASE morales_gustavo;
--DROP TABLE IF EXISTS train_cupid;
--DROP TABLE IF EXISTS test_cupid;
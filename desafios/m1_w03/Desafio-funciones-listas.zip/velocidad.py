def promedio(vector):

    return sum(vector)/len(vector)
